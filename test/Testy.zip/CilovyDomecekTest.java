import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CilovyDomecekTest {

    private List<Figurka> figurky;

    @Test
    void jeVolno(int pozice) {
        assertTrue(figurky.get(pozice)==null);
        assertFalse(figurky.get(pozice)!=null);
    }

    @Test
    void vlozFigurku(int pozice, Figurka figurka){
        figurky.set(pozice, figurka);
    }

    @Test
    void jePlno() {
        assertFalse(figurky.contains(null));
    }

    @Test
    void getFigurkyKPohybu(int pocet) {
        List<Figurka> figurkaList = new ArrayList<>();
        for (Figurka f:figurky){
            for (int i=figurky.indexOf(f);i<pocet;i++) {
                if (figurky.get(i)==null) figurkaList.add(f);
            }
        }
        System.out.print(figurkaList);
    }
}
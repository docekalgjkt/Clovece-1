import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class StartovniDomecekTest {

    private LinkedList<Figurka> figurky = new LinkedList<>();

    @Test
    void jePrazdny() {
        assertTrue(figurky.isEmpty());
    }
}